# 说明

- 在线MarkDown简历书写工具 冷熊简历 http://link.ftqq.com/0rsRL  
- 自架版 DeerResume https://github.com/geekcompany/DeerResume
- 教学：《如何写好技术简历》 http://link.ftqq.com/KWkVX

## 程序员简历模板列表

- [PHP程序员简历模板](php.md)
- [iOS程序员简历模板](ios.md)
- [Android程序员简历模板](android.md)
- [Web前端程序员简历模板](web.md)
- [Java程序员简历模板](java.md)
- [C/C++程序员简历模板](c.md)
- [NodeJS程序员简历模板](node.md)
- [架构师简历模板](architect.md)
- [通用程序员简历模板](etc.md)
