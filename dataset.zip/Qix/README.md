

## About Me

WeiBo: [@廖君_Jun](http://weibo.com/ty4z2008)

Twitter: [@廖君](https://twitter.com/ty4z2008)

E-Mail: ty4z2008@gmail.com

Scale System Channel: [https://t.me/scalesystem](https://t.me/scalesystem)

**NOTE** 

There may be some incorrect information in the article. I hope i can correct error with you.  you can contact me with Email or PR

## Pull Request welcome:blush:

## My translation

### node-mysql document translate

node-mysql offcial document:https://github.com/felixge/node-mysql/blob/master/Readme.md

node-mysql Chinese document:https://github.com/ty4z2008/Qix/blob/master/node.md

## Machine Learning And deep learning Resources

Chapter 1:https://github.com/ty4z2008/Qix/blob/master/dl.md

Chapter 2:https://github.com/ty4z2008/Qix/blob/master/dl2.md

## Golang learning resources

Link ：https://github.com/ty4z2008/Qix/blob/master/golang.md


## PostgreSQL database resources

Link  ：https://github.com/ty4z2008/Qix/blob/master/pg.md

## Distributed system resource

Links ：https://github.com/ty4z2008/Qix/blob/master/ds.md

## Additional notes

Dear friends. In order to respect to  the efforts   of authorship. In the reading process, when you find that resource the authorship is incorrect I also want you to[Submit feedback](https://github.com/ty4z2008/Qix/issues)。Thanks buddy！

## License

[MIT License](https://github.com/ty4z2008/Qix/blob/master/License.md)
